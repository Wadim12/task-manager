from django.contrib import admin
from django.urls import include, path

from tasks import views as tasks_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', tasks_views.home, name='home'),
    path('tasks/', include('tasks.urls')),
    path('users/', include('users.urls')),
]
