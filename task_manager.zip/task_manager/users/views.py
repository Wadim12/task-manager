from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST


def register(request):
    """Регистрация: после успеха пользователь сразу входит в систему."""
    if request.user.is_authenticated:
        return redirect('tasks:task_list')
    if request.method != 'POST':
        form = UserCreationForm()
    else:
        form = UserCreationForm(data=request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Добро пожаловать! Регистрация прошла успешно.')
            return redirect('tasks:task_list')
    return render(request, 'users/register.html', {'form': form})


@require_POST
def logout_view(request):
    """Выход только методом POST (с CSRF-токеном)."""
    logout(request)
    return redirect('home')
