from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Case, F, IntegerField, When
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import TaskForm
from .models import Task


def home(request):
    """Главная страница, доступна всем."""
    return render(request, 'tasks/home.html')


@login_required
def task_list(request):
    """Список задач текущего пользователя.

    Порядок: невыполненные сначала, затем высокий -> обычный -> низкий
    приоритет, затем ближайший срок (задачи без срока в конце), затем
    более новые задачи.
    """
    tasks = (
        Task.objects.filter(owner=request.user)
        .annotate(
            priority_order=Case(
                When(priority=Task.PRIORITY_HIGH, then=0),
                When(priority=Task.PRIORITY_NORMAL, then=1),
                default=2,
                output_field=IntegerField(),
            )
        )
        .order_by(
            'completed',
            'priority_order',
            F('due_date').asc(nulls_last=True),
            '-date_added',
            'id',
        )
    )
    return render(request, 'tasks/task_list.html', {'tasks': tasks})


@login_required
def task_new(request):
    """Создание задачи. Владелец назначается в представлении."""
    if request.method != 'POST':
        form = TaskForm()
    else:
        form = TaskForm(data=request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.owner = request.user
            task.save()
            messages.success(request, 'Задача создана.')
            return redirect('tasks:task_list')
    return render(request, 'tasks/task_form.html', {'form': form, 'title': 'Новая задача'})


@login_required
def task_edit(request, task_id):
    """Редактирование задачи (только владельцем)."""
    task = get_object_or_404(Task, id=task_id, owner=request.user)
    if request.method != 'POST':
        form = TaskForm(instance=task)
    else:
        form = TaskForm(instance=task, data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Изменения сохранены.')
            return redirect('tasks:task_list')
    context = {'form': form, 'task': task, 'title': 'Редактирование задачи'}
    return render(request, 'tasks/task_form.html', context)


@login_required
def task_delete(request, task_id):
    """Удаление: GET показывает подтверждение, удаляет только POST."""
    task = get_object_or_404(Task, id=task_id, owner=request.user)
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'Задача удалена.')
        return redirect('tasks:task_list')
    return render(request, 'tasks/task_confirm_delete.html', {'task': task})


@login_required
@require_POST
def task_toggle(request, task_id):
    """Отметить задачу выполненной / вернуть в работу (только POST)."""
    task = get_object_or_404(Task, id=task_id, owner=request.user)
    task.completed = not task.completed
    task.save(update_fields=['completed'])
    if task.completed:
        messages.success(request, 'Задача отмечена выполненной.')
    else:
        messages.info(request, 'Задача возвращена в работу.')
    return redirect('tasks:task_list')
