from datetime import timedelta

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .forms import TaskForm
from .models import Task

User = get_user_model()
PASSWORD = 'Str0ng-pass-123'


class BaseTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.alice = User.objects.create_user('alice', password=PASSWORD)
        cls.bob = User.objects.create_user('bob', password=PASSWORD)
        cls.alice_task = Task.objects.create(owner=cls.alice, title='Задача Алисы')
        cls.bob_task = Task.objects.create(owner=cls.bob, title='Задача Боба')

    def login_alice(self):
        self.client.login(username='alice', password=PASSWORD)


class ModelTests(BaseTestCase):
    def test_str_returns_title(self):
        self.assertEqual(str(self.alice_task), 'Задача Алисы')

    def test_defaults(self):
        self.assertEqual(self.alice_task.priority, Task.PRIORITY_NORMAL)
        self.assertFalse(self.alice_task.completed)
        self.assertIsNone(self.alice_task.due_date)

    def test_is_overdue(self):
        past = timezone.now() - timedelta(days=1)
        future = timezone.now() + timedelta(days=1)
        overdue = Task(owner=self.alice, title='a', due_date=past)
        self.assertTrue(overdue.is_overdue)
        overdue.completed = True
        self.assertFalse(overdue.is_overdue)
        self.assertFalse(Task(owner=self.alice, title='b', due_date=future).is_overdue)
        self.assertFalse(Task(owner=self.alice, title='c').is_overdue)


class PublicPagesTests(BaseTestCase):
    def test_home_available_to_anonymous(self):
        self.assertEqual(self.client.get('/').status_code, 200)

    def test_login_and_register_pages_available(self):
        self.assertEqual(self.client.get('/users/login/').status_code, 200)
        self.assertEqual(self.client.get('/users/register/').status_code, 200)


class AuthRequiredTests(BaseTestCase):
    def assertRedirectsToLogin(self, response, url):
        self.assertRedirects(
            response, f"{reverse('users:login')}?next={url}",
            fetch_redirect_response=False,
        )

    def test_list_requires_login(self):
        self.assertRedirectsToLogin(self.client.get('/tasks/'), '/tasks/')

    def test_new_requires_login(self):
        self.assertRedirectsToLogin(self.client.get('/tasks/new/'), '/tasks/new/')

    def test_edit_requires_login(self):
        url = f'/tasks/{self.alice_task.id}/edit/'
        self.assertRedirectsToLogin(self.client.get(url), url)

    def test_delete_requires_login(self):
        url = f'/tasks/{self.alice_task.id}/delete/'
        self.assertRedirectsToLogin(self.client.post(url), url)
        self.assertTrue(Task.objects.filter(id=self.alice_task.id).exists())

    def test_toggle_requires_login(self):
        url = f'/tasks/{self.alice_task.id}/toggle/'
        self.assertRedirectsToLogin(self.client.post(url), url)
        self.alice_task.refresh_from_db()
        self.assertFalse(self.alice_task.completed)


class RegistrationTests(TestCase):
    def test_register_creates_user_and_logs_in(self):
        response = self.client.post('/users/register/', {
            'username': 'newuser',
            'password1': PASSWORD,
            'password2': PASSWORD,
        })
        self.assertRedirects(response, reverse('tasks:task_list'))
        self.assertTrue(User.objects.filter(username='newuser').exists())
        self.assertIn('_auth_user_id', self.client.session)

    def test_register_with_mismatched_passwords_fails(self):
        response = self.client.post('/users/register/', {
            'username': 'newuser',
            'password1': PASSWORD,
            'password2': 'other-pass-456',
        })
        self.assertEqual(response.status_code, 200)
        self.assertFalse(User.objects.filter(username='newuser').exists())


class LogoutTests(BaseTestCase):
    def test_logout_via_post(self):
        self.login_alice()
        response = self.client.post('/users/logout/')
        self.assertRedirects(response, reverse('home'))
        self.assertNotIn('_auth_user_id', self.client.session)

    def test_logout_via_get_not_allowed(self):
        self.login_alice()
        response = self.client.get('/users/logout/')
        self.assertEqual(response.status_code, 405)
        self.assertIn('_auth_user_id', self.client.session)


class TaskListTests(BaseTestCase):
    def test_list_shows_only_own_tasks(self):
        self.login_alice()
        response = self.client.get('/tasks/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Задача Алисы')
        self.assertNotContains(response, 'Задача Боба')
        self.assertEqual(list(response.context['tasks']), [self.alice_task])

    def test_list_ordering(self):
        now = timezone.now()
        done = Task.objects.create(owner=self.alice, title='done', completed=True,
                                   priority=Task.PRIORITY_HIGH)
        low = Task.objects.create(owner=self.alice, title='low', priority=Task.PRIORITY_LOW)
        high_late = Task.objects.create(owner=self.alice, title='high_late',
                                        priority=Task.PRIORITY_HIGH,
                                        due_date=now + timedelta(days=5))
        high_soon = Task.objects.create(owner=self.alice, title='high_soon',
                                        priority=Task.PRIORITY_HIGH,
                                        due_date=now + timedelta(days=1))
        high_none = Task.objects.create(owner=self.alice, title='high_none',
                                        priority=Task.PRIORITY_HIGH)
        self.login_alice()
        tasks = list(self.client.get('/tasks/').context['tasks'])
        self.assertEqual(
            tasks,
            [high_soon, high_late, high_none, self.alice_task, low, done],
        )

    def test_overdue_task_is_marked(self):
        Task.objects.create(owner=self.alice, title='Просроченная',
                            due_date=timezone.now() - timedelta(days=2))
        self.login_alice()
        self.assertContains(self.client.get('/tasks/'), 'Просрочена')


class TaskCreateTests(BaseTestCase):
    def test_create_assigns_current_user_as_owner(self):
        self.login_alice()
        response = self.client.post('/tasks/new/', {
            'title': 'Новая',
            'description': 'Описание',
            'priority': 'high',
            'due_date': '2030-01-15T10:30',
        })
        self.assertRedirects(response, reverse('tasks:task_list'))
        task = Task.objects.get(title='Новая')
        self.assertEqual(task.owner, self.alice)
        self.assertEqual(task.priority, 'high')
        self.assertIsNotNone(task.due_date)

    def test_owner_cannot_be_forged_via_post(self):
        self.login_alice()
        self.client.post('/tasks/new/', {
            'title': 'Подделка',
            'priority': 'normal',
            'owner': self.bob.id,
        })
        self.assertEqual(Task.objects.get(title='Подделка').owner, self.alice)

    def test_invalid_due_date_shows_form_error_not_500(self):
        self.login_alice()
        response = self.client.post('/tasks/new/', {
            'title': 'Плохая дата',
            'priority': 'normal',
            'due_date': 'не-дата',
        })
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['form'].errors.get('due_date'))
        self.assertFalse(Task.objects.filter(title='Плохая дата').exists())

    def test_title_is_required(self):
        self.login_alice()
        response = self.client.post('/tasks/new/', {'title': '', 'priority': 'normal'})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.context['form'].errors.get('title'))


class TaskFormTests(TestCase):
    def test_form_fields(self):
        self.assertEqual(
            list(TaskForm().fields),
            ['title', 'description', 'due_date', 'priority', 'completed'],
        )


class TaskEditTests(BaseTestCase):
    def test_owner_can_edit(self):
        self.login_alice()
        url = f'/tasks/{self.alice_task.id}/edit/'
        self.assertEqual(self.client.get(url).status_code, 200)
        response = self.client.post(url, {
            'title': 'Изменено',
            'priority': 'low',
            'due_date': '2031-05-01T08:00',
        })
        self.assertRedirects(response, reverse('tasks:task_list'))
        self.alice_task.refresh_from_db()
        self.assertEqual(self.alice_task.title, 'Изменено')
        self.assertEqual(self.alice_task.priority, 'low')
        self.assertIsNotNone(self.alice_task.due_date)

    def test_cannot_view_foreign_task_edit_page(self):
        self.login_alice()
        self.assertEqual(self.client.get(f'/tasks/{self.bob_task.id}/edit/').status_code, 404)

    def test_cannot_edit_foreign_task(self):
        self.login_alice()
        response = self.client.post(f'/tasks/{self.bob_task.id}/edit/', {
            'title': 'Взлом', 'priority': 'high',
        })
        self.assertEqual(response.status_code, 404)
        self.bob_task.refresh_from_db()
        self.assertEqual(self.bob_task.title, 'Задача Боба')

    def test_edit_missing_id_returns_404(self):
        self.login_alice()
        self.assertEqual(self.client.get('/tasks/999999/edit/').status_code, 404)


class TaskDeleteTests(BaseTestCase):
    def test_get_shows_confirmation_and_does_not_delete(self):
        self.login_alice()
        response = self.client.get(f'/tasks/{self.alice_task.id}/delete/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Подтверждение удаления')
        self.assertTrue(Task.objects.filter(id=self.alice_task.id).exists())

    def test_post_deletes_own_task(self):
        self.login_alice()
        response = self.client.post(f'/tasks/{self.alice_task.id}/delete/')
        self.assertRedirects(response, reverse('tasks:task_list'))
        self.assertFalse(Task.objects.filter(id=self.alice_task.id).exists())

    def test_cannot_delete_foreign_task(self):
        self.login_alice()
        response = self.client.post(f'/tasks/{self.bob_task.id}/delete/')
        self.assertEqual(response.status_code, 404)
        self.assertTrue(Task.objects.filter(id=self.bob_task.id).exists())

    def test_cannot_open_delete_page_of_foreign_task(self):
        self.login_alice()
        self.assertEqual(self.client.get(f'/tasks/{self.bob_task.id}/delete/').status_code, 404)

    def test_delete_missing_id_returns_404(self):
        self.login_alice()
        self.assertEqual(self.client.post('/tasks/999999/delete/').status_code, 404)


class TaskToggleTests(BaseTestCase):
    def test_toggle_complete_and_back(self):
        self.login_alice()
        url = f'/tasks/{self.alice_task.id}/toggle/'
        self.client.post(url)
        self.alice_task.refresh_from_db()
        self.assertTrue(self.alice_task.completed)
        self.client.post(url)
        self.alice_task.refresh_from_db()
        self.assertFalse(self.alice_task.completed)

    def test_toggle_via_get_not_allowed(self):
        self.login_alice()
        response = self.client.get(f'/tasks/{self.alice_task.id}/toggle/')
        self.assertEqual(response.status_code, 405)
        self.alice_task.refresh_from_db()
        self.assertFalse(self.alice_task.completed)

    def test_cannot_toggle_foreign_task(self):
        self.login_alice()
        response = self.client.post(f'/tasks/{self.bob_task.id}/toggle/')
        self.assertEqual(response.status_code, 404)
        self.bob_task.refresh_from_db()
        self.assertFalse(self.bob_task.completed)

    def test_toggle_missing_id_returns_404(self):
        self.login_alice()
        self.assertEqual(self.client.post('/tasks/999999/toggle/').status_code, 404)
