from django import forms

from .models import Task

DATETIME_LOCAL_FORMAT = '%Y-%m-%dT%H:%M'


class TaskForm(forms.ModelForm):
    """Форма задачи. Поля owner и date_added пользователь не передаёт."""

    class Meta:
        model = Task
        fields = ['title', 'description', 'due_date', 'priority', 'completed']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'due_date': forms.DateTimeInput(
                attrs={'type': 'datetime-local'},
                format=DATETIME_LOCAL_FORMAT,
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['due_date'].input_formats = [
            DATETIME_LOCAL_FORMAT,
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%d %H:%M',
            '%Y-%m-%d %H:%M:%S',
            '%d.%m.%Y %H:%M',
        ]
        self.fields['due_date'].help_text = 'Необязательно. Формат: ГГГГ-ММ-ДД ЧЧ:ММ'
