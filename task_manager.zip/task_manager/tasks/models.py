from django.conf import settings
from django.db import models
from django.utils import timezone


class Task(models.Model):
    """Задача пользователя."""

    PRIORITY_LOW = 'low'
    PRIORITY_NORMAL = 'normal'
    PRIORITY_HIGH = 'high'
    PRIORITY_CHOICES = [
        (PRIORITY_LOW, 'Низкий'),
        (PRIORITY_NORMAL, 'Обычный'),
        (PRIORITY_HIGH, 'Высокий'),
    ]

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='tasks',
        verbose_name='Владелец',
    )
    title = models.CharField('Название', max_length=200)
    description = models.TextField('Описание', blank=True)
    date_added = models.DateTimeField('Дата создания', auto_now_add=True)
    due_date = models.DateTimeField('Срок выполнения', null=True, blank=True)
    priority = models.CharField(
        'Приоритет',
        max_length=10,
        choices=PRIORITY_CHOICES,
        default=PRIORITY_NORMAL,
    )
    completed = models.BooleanField('Выполнена', default=False)

    class Meta:
        verbose_name = 'задача'
        verbose_name_plural = 'задачи'

    def __str__(self):
        return self.title

    @property
    def is_overdue(self):
        """Невыполненная задача, срок которой уже прошёл."""
        return bool(
            not self.completed
            and self.due_date
            and self.due_date < timezone.now()
        )
